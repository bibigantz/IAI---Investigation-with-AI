package com.example.abnormalapp

/*
Expected Abnormal Values
When monitoring this app with ADB and Android Studio profilers,
participants should look for the following unusual patterns:

Memory Usage (RAM): Higher than normal, with values likely over 100 MB due to the
accumulating list (intensiveDataList). This should stand out as a leak since most
other apps would free memory not in active use.
CPU Usage: High and consistent due to performCpuIntensiveTask(), which forces the
CPU to perform unnecessary calculations.
Battery Usage: Noticeable drain due to location updates and CPU load, contrasting
with typical apps that enter low-power states when idle.
Sensor Usage (GPS): High-frequency location updates with no purpose, showing
unusual access frequency compared to apps that use GPS only as needed.
 */
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkAndRequestPermissions()

        findViewById<Button>(R.id.cpu_btn).setOnClickListener {
            // Run CPU-heavy tasks
            startHeavyCpuTasks()

        }



    }


    private fun startHeavyCpuTasks() {
        // Start multiple heavy tasks in parallel
        val executorService: ExecutorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors())
        val range = 500000 // Task range to cause heavy number crunching

        for (i in 0 until 1000) { // Launching multiple tasks to run in parallel
            executorService.submit {
                calculateFibonacci(40) // Intense Fibonacci recursive calculation
                performPrimeCalculations(range) // Run heavy prime number task
                performMatrixMultiplication() // Run CPU-intensive matrix multiplication
            }
        }
    }

    // Heavy recursive Fibonacci function (will cause extreme CPU load)
    private fun calculateFibonacci(n: Int) {
        if (n <= 1) return
        calculateFibonacci(n - 1)
        calculateFibonacci(n - 2)
    }

    // Heavy prime number calculations (brute force)
    private fun performPrimeCalculations(limit: Int) {
        for (num in 2..limit) {
            if (isPrime(num)) {
                // Log each prime number (could slow down app, but shows work is being done)
                // Log.d("Prime", "Prime found: $num")
            }
        }
    }

    // Helper function to check for prime numbers
    private fun isPrime(number: Int): Boolean {
        for (i in 2 until number) {
            if (number % i == 0) {
                return false
            }
        }
        return true
    }

    // Matrix multiplication for CPU stress (multiplies large matrices)
    private fun performMatrixMultiplication() {
        val size = 1000 // Matrix size to create a large CPU load
        val matrixA = Array(size) { DoubleArray(size) { Math.random() } }
        val matrixB = Array(size) { DoubleArray(size) { Math.random() } }
        val result = Array(size) { DoubleArray(size) }

        // Multiply matrixA and matrixB to fill 'result' matrix
        for (i in 0 until size) {
            for (j in 0 until size) {
                result[i][j] = 0.0
                for (k in 0 until size) {
                    result[i][j] += matrixA[i][k] * matrixB[k][j]
                }
            }
        }
    }


    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        // Location permission check
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        // Notification permission check (Android 13+)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest.toTypedArray(), 0)
        } else {
            startResourceIntensiveService()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        // Check if permissions are granted
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startResourceIntensiveService()
        } else {
            // Handle permission denial if needed
        }
    }

    private fun startResourceIntensiveService() {
        val serviceIntent = Intent(this, ResourceIntensiveService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
    }
}
