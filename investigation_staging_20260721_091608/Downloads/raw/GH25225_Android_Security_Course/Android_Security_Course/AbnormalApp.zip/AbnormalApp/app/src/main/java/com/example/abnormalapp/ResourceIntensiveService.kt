package com.example.abnormalapp
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlin.random.Random

class ResourceIntensiveService : Service(), LocationListener {
    private val largeDataList = mutableListOf<ByteArray>()
    private val bitmapList = mutableListOf<Bitmap>()
    private lateinit var locationManager: LocationManager

    override fun onCreate() {
        super.onCreate()

        // Start foreground service with notification
        startForegroundServiceWithNotification()

        // Allocate large memory to increase memory usage
        allocateLargeData()
        createBitmapLoad()

        // Set up location manager and request updates
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        requestLocationUpdates()
    }

    private fun startForegroundServiceWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "ResourceIntensiveServiceChannel"
            val channel = NotificationChannel(
                channelId,
                "Resource Intensive Service",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)

            val notification: Notification = NotificationCompat.Builder(this, channelId)
                .setContentTitle("Resource Intensive Service")
                .setContentText("Running resource-intensive operations")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()

            startForeground(1, notification)
        }
    }

    private fun allocateLargeData() {
        // Allocate multiple large byte arrays
        for (i in 0 until 100) { // Increasing the count will increase memory use
            largeDataList.add(ByteArray(1024 * 1024)) // 1 MB per array
        }
    }

    private fun createBitmapLoad() {
        val options = BitmapFactory.Options().apply { inMutable = true }

        // Create and add large Bitmaps to consume memory
        for (i in 0 until 50) { // Increasing count to allocate more memory
            val bitmap = Bitmap.createBitmap(1024, 1024, Bitmap.Config.ARGB_8888)
            bitmapList.add(bitmap)
        }
    }

    private fun requestLocationUpdates() {
        try {
            // Request location updates every 5000ms (5 seconds) with 10 meter minimum distance
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                5000L, 10f, this
            )
        } catch (e: SecurityException) {
            // Handle the case where permission is not granted
            e.printStackTrace()
        }
    }

    override fun onLocationChanged(location: Location) {
        // Simulate GPS usage by logging the location or performing calculations
        val latitude = location.latitude
        val longitude = location.longitude
        // You can log or perform some actions to further simulate the use of location data
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        // Handle status change if needed
    }



    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Repeatedly refresh the bitmap data to maintain high memory use
        val random = Random(System.currentTimeMillis())
        for (bitmap in bitmapList) {
            bitmap.setPixel(
                random.nextInt(bitmap.width),
                random.nextInt(bitmap.height),
                random.nextInt()
            )
        }

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        largeDataList.clear()
        bitmapList.clear()
        locationManager.removeUpdates(this) // Remove location updates when service stops
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
