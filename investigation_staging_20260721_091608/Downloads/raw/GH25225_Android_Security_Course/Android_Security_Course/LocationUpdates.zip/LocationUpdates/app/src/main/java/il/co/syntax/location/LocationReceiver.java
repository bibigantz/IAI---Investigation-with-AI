package il.co.syntax.location;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class LocationReceiver extends BroadcastReceiver {

    final String ACTION = "il.co.syntax.action_get_last_location";
    @Override
    public void onReceive(Context context, Intent intent) {

        if(intent.getAction() == ACTION) {
            Toast.makeText(context, Utils.getLastLocation(context), Toast.LENGTH_SHORT).show();
        }
    }
}
