package com.example.dynamicmodule

class Calculation {
    fun add(a: Int, b: Int): Int {
        return a + b
    }
}