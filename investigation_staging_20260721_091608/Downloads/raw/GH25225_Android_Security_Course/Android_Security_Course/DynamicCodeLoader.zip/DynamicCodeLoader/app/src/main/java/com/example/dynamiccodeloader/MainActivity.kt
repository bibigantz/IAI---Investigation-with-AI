package com.example.dynamiccodeloader

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import dalvik.system.DexClassLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.math.BigInteger
import java.net.URL
import java.security.MessageDigest

class MainActivity : AppCompatActivity() {

    // Replace with the actual SHA-256 hash of your .dex file
    private val expectedDexHash = "580ed129548eeb9404b3e7ea1399d7e3eaacfe7a878536d2c2e37018511910f8"
        // "6a24f00aacb81d73dbb394d09b2fc2e11287653f77881f0a92cc9e95c44e9249"//"6625c9    private val expectedDexHash = \"6625c9d9a50288b09ef0c566f30cceaa6a6a3fe1a70ae5e71690bda7a1994adb\"//\"c770aed5f1d1e037be503213d79596a04bc9190cd50b6a8ea60cf17679c21176\"\nd9a50288b09ef0c566f30cceaa6a6a3fe1a70ae5e71690bda7a1994adb"//"c770aed5f1d1e037be503213d79596a04bc9190cd50b6a8ea60cf17679c21176"
//"568d977e5ac9744684dc5c0c4871dfbb7f9d412cd6fba923c0a3c95dfc90c510"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Lab convenience: allow the expected SHA-256 to be overridden from the launch
        // command so students can swap payloads without rebuilding the APK.
        // Real apps embed the hash and never trust an external source for it.
        //   adb shell am start -n com.example.dynamiccodeloader/.MainActivity --es hash <hex>
        val effectiveHash = intent.getStringExtra("hash") ?: expectedDexHash

        CoroutineScope(Dispatchers.IO).launch {
            // Download the dex file
       //     val dexFileUrl = "https://syntax.org.il/xtra/classes.dex" // replace with your URL
        //    val dexFileUrl = "http://172.16.3.50:8000/classes.dex" // replace with your URL
            val dexFileUrl = "http://127.0.0.1:8000/classes.dex"

            val dexFilePath = downloadDexFile(dexFileUrl, "classes.dex", this@MainActivity)

            // Verify file integrity
            val isVerified = verifyDexFileIntegrity(dexFilePath, effectiveHash)
            if (isVerified) {
                // Load and execute the dex file only if it passes verification
                withContext(Dispatchers.Main) {
                    loadAndExecuteDex(dexFilePath)
                }
            } else {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Dex file integrity check failed", Toast.LENGTH_LONG).show()
                }
                Log.e("DynamicLoading", "Dex file integrity check failed")
            }
        }
    }

    private suspend fun downloadDexFile(url: String, filename: String, context: Context): String {
        val dexFile = File(context.filesDir, filename)
        try {
            withContext(Dispatchers.IO) {
                URL(url).openStream().use { input ->
                    dexFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
            }
          //  dexFile.setReadOnly() //Solution for Android 14
            Log.d("DynamicLoading", "Dex file downloaded successfully")
        } catch (e: Exception) {
            Log.e("DynamicLoading", "Failed to download dex file", e)
        }
        return dexFile.absolutePath
    }

    private fun verifyDexFileIntegrity(filePath: String, expectedHash: String): Boolean {
        val sha256 = MessageDigest.getInstance("SHA-256")
        val file = File(filePath)
        FileInputStream(file).use { fis ->
            val buffer = ByteArray(1024)
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                sha256.update(buffer, 0, bytesRead)
            }
        }
        val fileHash = BigInteger(1, sha256.digest()).toString(16).padStart(64, '0')
        Log.d("DynamicLoading", "Calculated file hash: $fileHash")
        return fileHash.equals(expectedHash, ignoreCase = true)
    }

    private fun loadAndExecuteDex(dexFilePath: String) {
        val optimizedDir = File(applicationInfo.dataDir, "optimized_dex")
        if (!optimizedDir.exists()) {
            optimizedDir.mkdirs()
        }

        try {
            val dexClassLoader = DexClassLoader(
                dexFilePath,
                optimizedDir.absolutePath,
                null,
                classLoader
            )

            // Load the Calculation class dynamically
            //Remember to include also the class name!
            val calculationClass = dexClassLoader.loadClass("com.example.dynamic.Calculation")//"com.example.dynamic.Calculation")
            val calculationInstance = calculationClass.newInstance()

            // Use reflection to call the `div` method
            val divMethod = calculationClass.getMethod("div", Int::class.java, Int::class.java)
            val result = divMethod.invoke(calculationInstance, 90, 3) as Int

            Toast.makeText(this, "Dynamic code loaded successfully! Result: $result", Toast.LENGTH_LONG).show()
            Log.d("DynamicLoading", "Result of dynamic method: $result") // Logs: Result of add method: 8

        } catch (e: Exception) {
            Toast.makeText(this, "Error loading dex file $e", Toast.LENGTH_LONG).show()
            Log.e("DynamicLoading", "Error loading dex file dynamically", e)
        }
    }
}
