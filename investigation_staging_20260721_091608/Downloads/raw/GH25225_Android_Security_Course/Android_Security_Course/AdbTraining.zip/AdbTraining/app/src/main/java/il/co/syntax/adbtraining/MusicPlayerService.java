package il.co.syntax.adbtraining;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.io.IOException;

/**
 * Created by erankatsav on 03/04/2018.
 */

public class MusicPlayerService extends Service implements MediaPlayer.OnCompletionListener,MediaPlayer.OnPreparedListener{

    private MediaPlayer player = new MediaPlayer();
    private boolean showNotif = true;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        player.setOnCompletionListener(this);
        player.setOnPreparedListener(this);
        player.reset();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        String link  = intent.getStringExtra("link");
        showNotif = intent.getBooleanExtra("notif",true);

        if(!player.isPlaying()) {
            try {
                Toast.makeText(this, link, Toast.LENGTH_SHORT).show();
                player.setDataSource(link);
                //player.prepare(); //sync function
                player.prepareAsync();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(player!=null) {
            if(player.isPlaying())
                player.stop();
            player.release();
        }
    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        stopSelf();
    }

    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {

        player.start();

        if(showNotif) {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel channel = new NotificationChannel("id", "name", NotificationManager.IMPORTANCE_DEFAULT);
                NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                manager.createNotificationChannel(channel);
            }
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "id");

            builder.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Playing music")
                    .setContentText("Playing legendary Bob, enjoy");

            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("playing", true);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
            builder.setContentIntent(pendingIntent);

            startForeground(1, builder.build());
        }
    }
}
