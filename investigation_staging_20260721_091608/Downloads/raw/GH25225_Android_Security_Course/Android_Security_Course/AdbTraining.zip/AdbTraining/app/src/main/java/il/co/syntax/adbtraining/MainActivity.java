package il.co.syntax.adbtraining;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    BroadcastReceiver receiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSharedPreferences("moshe",MODE_PRIVATE).edit().putString("key0","eran").commit();
        getSharedPreferences("moshe1",MODE_PRIVATE).edit().putBoolean("key0",true).commit();
        getSharedPreferences("moshe2",MODE_PRIVATE).edit().putInt("key0",646).commit();



        if(PreferenceManager.getDefaultSharedPreferences(this).contains("key_one")) {

            TextView textView = findViewById(R.id.text_view);
            textView.setText(PreferenceManager.getDefaultSharedPreferences(this).getString("key_one",""));
        }

        IntentFilter filter = new IntentFilter("il.co.sytax.MESSAGE_RECEIVER");
        receiver = new MessageReceiver();
        registerReceiver(receiver,filter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }
}