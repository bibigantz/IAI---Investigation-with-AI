#include <jni.h>
#include <string>
#include <vector>
#include <cstdint>

// ROT13 cipher implementation
std::string rot13(const std::string& input) {
    std::string result = input;
    for (char& c : result) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
            char base = (c >= 'a' && c <= 'z') ? 'a' : 'A';
            c = base + (c - base + 13) % 26;
        }
    }
    return result;
}

// Simple substitution cipher (shift each byte by a value)
std::string bytesShift(const std::string& input, int shift) {
    std::string result = input;
    for (char& c : result) {
        c = c + shift;
    }
    return result;
}

// Hex string to bytes conversion
std::string hexToString(const std::string& hex) {
    std::string result;
    for (size_t i = 0; i < hex.length(); i += 2) {
        std::string byteString = hex.substr(i, 2);
        char byte = (char)strtol(byteString.c_str(), nullptr, 16);
        result += byte;
    }
    return result;
}

// RC4-like stream cipher
std::string customStreamCipher(const std::string& input, const std::string& key) {
    std::vector<uint8_t> s(256);
    std::vector<uint8_t> k(256);

    // Initialize S-box
    for (int i = 0; i < 256; i++) {
        s[i] = i;
        k[i] = key[i % key.length()];
    }

    // Key scheduling
    int j = 0;
    for (int i = 0; i < 256; i++) {
        j = (j + s[i] + k[i]) % 256;
        std::swap(s[i], s[j]);
    }

    // Stream generation and XOR with plaintext
    std::string result = input;
    int i = 0, x;
    j = 0;

    for (size_t n = 0; n < input.length(); n++) {
        i = (i + 1) % 256;
        j = (j + s[i]) % 256;
        std::swap(s[i], s[j]);
        x = s[(s[i] + s[j]) % 256];
        result[n] = input[n] ^ x;
    }

    return result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_securitychallenge_MainActivity_getSecretString(JNIEnv* env, jobject /* this */) {
    // The truth is out there - Encrypted with ROT13
    std::string encrypted = "Gur gehgu vf bhg gurer";

    // Hint in commenting style
    /*
    *  T + 13 = G
    *  H + 13 = U
    *  E + 13 = R
    */

    // Note: In a real challenge, we might not include the decryption here, but for this exercise
    // we're showing how the decryption would work in the native code for teaching purposes
    std::string decrypted = rot13(encrypted);

    return env->NewStringUTF(encrypted.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_securitychallenge_MainActivity_getApiCredentials(JNIEnv* env, jobject /* this */) {
    // Encrypted API key and password
    // The hex string decodes to a password: "APIkey:S3cretP@ssw0rd!"
    std::string hexEncoded = "4150496b65793a533363726574504073737730726421";

    // First step: Convert from hex
   // std::string byteShifted = hexToString(hexEncoded);

    // Second step: Byte-shift by -3 (hint is in the "+++++" sequence at the end which is unusual)
    // Count the '+' signs to get the shift value
  //  std::string apiCredentials = bytesShift(byteShifted, -3);

    // 43 79 62 65 72 43 68 65 66 20 69 73 20 61 77 65 73 6f 6d 65 21
    // Hex for "CyberChef is awesome!" - a hint to use CyberChef

    // "No More Secrets" - using custom stream cipher
    unsigned char encryptedDataRC4[] = {
            0xb7,0x04,0xe6,0x8b,0x11,0xa8,0xdc,0x28,0x7f,0xc0,0xd4,0x79,0x4b,0x10,0xa8,0x27
    };

    // Key: "hacktheplanet" (Reference to Hackers movie which also had the "No More Secrets" phrase)
    std::string keyRC4 = "hacktheplanet";

    std::string API_KEY = "JUST_SIMPLE_NOT_HIDDEN_API_KEY";

    // In a real exercise, we might not include the actual data conversion here
    std::string encryptedStr(reinterpret_cast<char*>(encryptedDataRC4), sizeof(encryptedDataRC4));
    std::string decrypted = customStreamCipher(encryptedStr, keyRC4);
    return env->NewStringUTF(hexEncoded.c_str());
}

// Hidden unused function that contains another secret
void unusedFunction() {
    // 43 79 62 65 72 43 68 65 66 20 69 73 20 61 77 65 73 6f 6d 65 21
    // Hex for "CyberChef is awesome!" - a hint to use CyberChef

    // "No More Secrets" - using custom stream cipher
    unsigned char encryptedDataRC4[] = {
            0xb7,0x04,0xe6,0x8b,0x11,0xa8,0xdc,0x28,0x7f,0xc0,0xd4,0x79,0x4b,0x10,0xa8,0x27
    };

    // Key: "hacktheplanet" (Reference to Hackers movie which also had the "No More Secrets" phrase)
    std::string keyRC4 = "hacktheplanet";

    // In a real exercise, we might not include the actual data conversion here
    std::string encryptedStr(reinterpret_cast<char*>(encryptedDataRC4), sizeof(encryptedDataRC4));
    std::string decrypted = customStreamCipher(encryptedStr, keyRC4);
}