package com.example.hardcodednativeapp

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.experimental.xor

class MainActivity : AppCompatActivity() {

    companion object {
        init {
            System.loadLibrary("native-lib")
        }

        // Hint: Sometimes the key is hidden in plain sight (XOR key: "FINDME")
        private const val TAG = "SecurityChallenge"
        private const val ENCRYPTED_STRING_1 = "CCZuCSI3I2kdIS43Iz09"  // Base64 encoded + XORed
        private const val API_KEY_HINT = "Check native code for API patterns"
    }

    // Native methods declared here
    external fun getSecretString(): String
    external fun getApiCredentials(): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Secret 1: First layer of encryption is Base64, then XOR with key hidden in code comments
        val secret1 = decryptXorString(ENCRYPTED_STRING_1)

        // Secret 2: Stored in native code
        val secret2 = getSecretString()

        // API Keys: Also in native code with different encryption
        val apiCredentials = getApiCredentials()

        // Additional secret with AES encryption
        val encryptedBytes = Base64.getDecoder().decode("2T7TvL94q0K5Vp4fI5xWnFn4rFA7WZ+KaDceiHAjZDvxm/C6mxr5+gCSBVxmaNVw")
        val key = "S3curityC0urse!!"  // KEY HINT: Check the app name and replace letters with similar numbers
        val aesDecrypted = decryptAES(encryptedBytes, key)

        // Don't log in production! This is just for the exercise
        Log.d(TAG, "Secrets discovered: $secret1, $secret2, $apiCredentials, $aesDecrypted")
    }

    private fun decryptXorString(base64String: String): String {
        val decodedBytes = Base64.getDecoder().decode(base64String)
        val xorKey = "FINDME".toByteArray()
        val result = ByteArray(decodedBytes.size)

        for (i in decodedBytes.indices) {
            result[i] = decodedBytes[i] xor xorKey[i % xorKey.size]
        }

        return String(result)
    }

    private fun decryptAES(encryptedBytes: ByteArray, keyString: String): String {
        try {
            // Key and IV setup
            val keyBytes = keyString.toByteArray(Charsets.UTF_8)
            val secretKey = SecretKeySpec(keyBytes, "AES")

            // Extract IV from first 16 bytes
            val iv = ByteArray(16)
            System.arraycopy(encryptedBytes, 0, iv, 0, iv.size)
            val ivSpec = IvParameterSpec(iv)

            // Extract ciphertext (everything after IV)
            val ciphertext = ByteArray(encryptedBytes.size - 16)
            System.arraycopy(encryptedBytes, 16, ciphertext, 0, ciphertext.size)

            // Decrypt
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec)
            val decryptedBytes = cipher.doFinal(ciphertext)

            return String(decryptedBytes)
        } catch (e: Exception) {
            Log.e(TAG, "AES decryption failed", e)
            return "Decryption failed"
        }
    }
}