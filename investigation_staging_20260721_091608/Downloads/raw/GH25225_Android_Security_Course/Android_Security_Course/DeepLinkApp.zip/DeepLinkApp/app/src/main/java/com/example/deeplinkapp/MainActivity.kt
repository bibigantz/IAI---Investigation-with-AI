package com.example.deeplinkapp

import android.content.ContentValues
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Bundle
import android.telephony.SmsManager
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var database: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Check if the SEND_SMS permission is already granted
        if (isSmsPermissionGranted()) {
         //   Toast.makeText(this, "SMS permission already granted!", Toast.LENGTH_SHORT).show()
            // Parse the incoming deep link
          //  val data: Uri? = intent?.data
            //val phoneNumber = data?.getQueryParameter("number")
            //val message = data?.getQueryParameter("message")

            val data = intent?.data?.getQueryParameter("data")
            if (data != null) {
                val parts = data.split(":")
                val number = parts[0]
                val message = parts[1]
                Log.d("DeepLinkReceiver", "Number: $number, Message: $message")
                if (!number.isNullOrEmpty() && !message.isNullOrEmpty()) {
                    sendSms(number, message)
                    finish()
                } else {
                    Log.e("DeepLinkActivity", "Invalid parameters in deep link")
                }
            }



        } else {
            requestSmsPermission()
        }
    }

    private fun sendSms(phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Log.i("DeepLinkActivity", "SMS sent to $phoneNumber with message: $message")
        } catch (e: Exception) {
            Log.e("DeepLinkActivity", "Failed to send SMS", e)
        }
    }
    private fun isSmsPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestSmsPermission() {
        // Launcher for permission request
        val requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()

        ) { isGranted ->
            if (isGranted) {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "SMS permission denied!", Toast.LENGTH_SHORT).show()
            }
        }

        // Show permission rationale if needed
        if (shouldShowRequestPermissionRationale(android.Manifest.permission.SEND_SMS)) {
            Toast.makeText(
                this,
                "SMS permission is needed to send messages from this app.",
                Toast.LENGTH_LONG
            ).show()
        }

        // Request the permission
        requestPermissionLauncher.launch(android.Manifest.permission.SEND_SMS)
    }
}