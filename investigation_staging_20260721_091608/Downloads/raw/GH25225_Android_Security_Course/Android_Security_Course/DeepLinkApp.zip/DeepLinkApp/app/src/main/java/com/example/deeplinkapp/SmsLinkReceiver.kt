package com.example.deeplinkapp


import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.telephony.SmsManager
import android.util.Log

class SmsLinkReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
     //   val data: Uri? = intent?.data
        //val phoneNumber = data?.getQueryParameter("number")
        //val message = data?.getQueryParameter("message")

        val data = intent?.data?.getQueryParameter("data")

        if (data != null) {
            val parts = data.split(":")
            val number = parts[0]
            val message = parts[1]
            if (!number.isNullOrEmpty() && !message.isNullOrEmpty()) {
                sendSms(number, message)
            } else {
                Log.e("DeepLinkReceiver", "Invalid parameters in deep link")
            }
        }

    }

    private fun sendSms(phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Log.i("DeepLinkReceiver", "SMS sent to $phoneNumber with message: $message")
        } catch (e: Exception) {
            Log.e("DeepLinkReceiver", "Failed to send SMS", e)
        }
    }
}