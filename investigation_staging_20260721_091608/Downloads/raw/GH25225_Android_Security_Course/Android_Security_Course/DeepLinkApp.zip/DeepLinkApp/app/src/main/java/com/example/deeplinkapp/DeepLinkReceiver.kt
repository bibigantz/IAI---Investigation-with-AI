package com.example.deeplinkapp

import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.AsyncTask
import android.widget.Toast

class DeepLinkReceiver : BroadcastReceiver() {

    private lateinit var database: SQLiteDatabase

    override fun onReceive(context: Context, intent: Intent?) {
        val username = intent?.data?.getQueryParameter("username")

        // Initialize database and insert dummy data if needed
        database = context.openOrCreateDatabase("UserData.db", Context.MODE_PRIVATE, null)
        setupDatabase()
        insertDummyData()

        // Execute SQL injection with the provided username
        if (username != null) {
            unsafeSQLQuery(context, username)
        }
    }

    // Setup the database if it doesn't exist
    private fun setupDatabase() {
        database.execSQL("CREATE TABLE IF NOT EXISTS Users (Name TEXT, Password TEXT)")
    }

    // Insert dummy data into the database if it doesn't exist
    private fun insertDummyData() {
        if (database.query("Users", null, null, null, null, null, null).count == 0) {
            val values1 = ContentValues().apply {
                put("Name", "Alice")
                put("Password", "alice_pass")
            }
            val values2 = ContentValues().apply {
                put("Name", "Bob")
                put("Password", "bob_pass")
            }
            database.insert("Users", null, values1)
            database.insert("Users", null, values2)
        }
    }

    // Perform an unsafe SQL query based on the username parameter
    private fun unsafeSQLQuery(context: Context, username: String) {
        val query = "SELECT * FROM Users WHERE Name = '$username'"
        val cursor = database.rawQuery(query, null)

        // Collect all retrieved data into a single string
        val result = StringBuilder()
        while (cursor.moveToNext()) {
            val retrievedName = cursor.getString(cursor.getColumnIndexOrThrow("Name"))
            val retrievedPassword = cursor.getString(cursor.getColumnIndexOrThrow("Password"))
            result.append("User: $retrievedName, Password: $retrievedPassword\n")
        }
        cursor.close()

        // Show the result in a Toast message
        if (result.isNotEmpty()) {
            Toast.makeText(context, result.toString(), Toast.LENGTH_LONG).show()
        }
    }
}
